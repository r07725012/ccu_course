package com.example.user.eldertour;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by user on 2017/2/19.
 */

public class MemberNonFirstCondition extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.member_nonfirst_test);




    }

}
