package com.example.user.eldertour;


import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;

public class SuitItemDetail extends AppCompatActivity {

//    int[] suit_pics = new int[]{
//            R.drawable.pic0, R.drawable.pic1, R.drawable.pic2, R.drawable.pic3, R.drawable.pic4, R.drawable.pic5, R.drawable.pic6, R.drawable.pic7, R.drawable.pic8, R.drawable.pic9, R.drawable.pic10,
//            R.drawable.pic11, R.drawable.pic12, R.drawable.pic13, R.drawable.pic14, R.drawable.pic15, R.drawable.pic16, R.drawable.pic17, R.drawable.pic18, R.drawable.pic19, R.drawable.pic20,
//            R.drawable.pic21, R.drawable.pic22, R.drawable.pic23, R.drawable.pic24, R.drawable.pic25, R.drawable.pic26, R.drawable.pic27, R.drawable.pic28, R.drawable.pic29, R.drawable.pic30,
//            R.drawable.pic31, R.drawable.pic32, R.drawable.pic29, R.drawable.pic30, R.drawable.pic31, R.drawable.pic32};
//
//    SharedPreferences pref = getSharedPreferences("Api_suit", 0);
//    ImageView imageView2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.suit_item_detail);
//        if (!pref.getString("Api_jstring", "").equals("") && pref.getInt("suit_index",0 )<33){
//            imageView2 = (ImageView) findViewById(R.id.imageView2);
//            imageView2.setImageResource(suit_pics[pref.getInt("suit_index", 0)]);
//            complete_detail();
//
//
//        }




    }
    void complete_detail(){

    }
}
